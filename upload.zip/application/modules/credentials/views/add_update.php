<form action="<?php echo base_url()."credentials/add_edit"; ?>" method="post" role="form" id="form" enctype="multipart/form-data" style="padding: 0px 10px">
 <?php if(isset($data->credentials_id)){?><input type="hidden"  name="id" value="<?php echo isset($data->credentials_id) ?$data->credentials_id : "";?>"> <?php } ?>
 <div class="box-body"><div class="form-group form-float">
<div class="form-line"><input type="text" class="form-control" id="credentials_domain" name="credentials_domain" required value="<?php echo isset($data->credentials_domain)?$data->credentials_domain:"";?>"  >
<label for="credentials_domain" class="form-label"><?php echo lang('domain'); ?> <span class="text-red">*</span></label>
</div></div>
<div class="form-group form-float">
<div class="form-line"><input type="text" class="form-control" id="credentials_type" name="credentials_type"  value="<?php echo isset($data->credentials_type)?$data->credentials_type:"";?>"  >
<label for="credentials_type" class="form-label"><?php echo lang('type'); ?> </label>
</div></div>
<div class="form-group form-float">
<div class="form-line"><input type="text" class="form-control" id="credentials_username" name="credentials_username"  value="<?php echo isset($data->credentials_username)?$data->credentials_username:"";?>"  >
<label for="credentials_username" class="form-label"><?php echo lang('username'); ?> </label>
</div></div>
<div class="form-group form-float">
<div class="input-group"><div class="form-line"><input type="password" class="form-control mka-pass-field" placeholder="<?php echo lang('password'); ?>" id="credentials_password" name="credentials_password" required value="<?php echo isset($data->credentials_password)?$data->credentials_password:"";?>"  >
</div><span class="input-group-addon mka-cl"><i class="material-icons">visibility</i></span></div></div>
<div class="form-group form-float">
<div class="form-line"><textarea rows="3" class="form-control" id="credentials_note" name="credentials_note" ><?php echo isset($data->credentials_note)?$data->credentials_note:"";?></textarea>
<label for="credentials_note" class="form-label"><?php echo lang('note'); ?> </label>
</div></div>
<div class="form-group form-float">
<div class="form-line"><label class="form-label"><?php echo lang('share_with'); ?> </label>
<?php echo MultipleSelectBoxDynamic("credentials_share_with","users","name",isset($data->credentials_share_with) ?$data->credentials_share_with : "", "", "user_type", "user");?>
</div></div>

        		<?php get_custom_fields('credentials', isset($data->credentials_id)?$data->credentials_id:NULL); ?>
        		</div>
                  <!-- /.box-body -->
                  <div class="box-footer">
                  	 <input type="submit" value="<?php echo lang('save'); ?>" name="save" class="btn btn-primary btn-color">
                  </div>
               </form>
            <script>
  				$.AdminBSB.input.activate();
  				$(document).ready(function() {
				  $('.mka-cl').on('click', function() {
				    if($(this).parents('.input-group').first().find('input.mka-pass-field').hasClass('showing')){
				      $(this).parents('.input-group').first().find('input.mka-pass-field').removeClass('showing').attr('type', 'password');
				    } else {
				      $(this).parents('.input-group').first().find('input.mka-pass-field').addClass('showing').attr('type', 'text');
				    }
				  });
				});
			</script>