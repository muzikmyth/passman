<?php
$lang['custom_fields'] = 'Custom Fields';
/*mka_custom_variables*/
