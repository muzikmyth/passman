<?php
$lang['about_us'] = 'About Us';
$lang['this_project_is_build_with'] = 'This project is build with';
$lang['web_project_builder'] = 'Web Project Builder';
$lang['allows_you_to_generate_php_code_of_projects_using_simple_user_interface_without_knowledge_of_programming_this_includes_crud_generator_user_authentication_user_roles_permission_and_much_more'] = 'allows you to generate PHP code of projects using simple user interface without knowledge of programming. This includes CRUD Generator, User Authentication, User Roles, Permission and much more';
$lang['visit_the_site_to_download_free_php_codeigniter_scripts_and_for_customization'] = 'Visit the site to download free php codeigniter scripts and for customization';
$lang['url'] = 'URL';