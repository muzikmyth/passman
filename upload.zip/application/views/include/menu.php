
<?php if(CheckPermission("Credentials", "all_read,own_read")){ ?>
					<li class="<?=($this->router->class==="credentials")?"active":"not-active"?>">
						<a href="<?php echo base_url("credentials"); ?>" data-crud_id="16624" class="EditCrud"><i class="glyphicon glyphicon-link"></i> <span><?php echo lang('credentials'); ?></span></a>
					</li><?php }?>
